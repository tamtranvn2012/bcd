<?php
/**
* PayPal® Pro Form responses.
*
* Copyright: © 2009-2011
* {@link http://www.websharks-inc.com/ WebSharks, Inc.}
* ( coded in the USA )
*
* This WordPress® plugin ( s2Member Pro ) is comprised of two parts:
*
* o (1) Its PHP code is licensed under the GPL license, as is WordPress®.
* 	You should have received a copy of the GNU General Public License,
* 	along with this software. In the main directory, see: /licensing/
* 	If not, see: {@link http://www.gnu.org/licenses/}.
*
* o (2) All other parts of ( s2Member Pro ); including, but not limited to:
* 	the CSS code, some JavaScript code, images, and design;
* 	are licensed according to the license purchased.
* 	See: {@link http://www.s2member.com/prices/}
*
* Unless you have our prior written consent, you must NOT directly or indirectly license,
* sub-license, sell, resell, or provide for free; part (2) of the s2Member Pro Module;
* or make an offer to do any of these things. All of these things are strictly
* prohibited with part (2) of the s2Member Pro Module.
*
* Your purchase of s2Member Pro includes free lifetime upgrades via s2Member.com
* ( i.e. new features, bug fixes, updates, improvements ); along with full access
* to our video tutorial library: {@link http://www.s2member.com/videos/}
*
* @package s2Member\PayPal
* @since 1.5
*/
if (realpath (__FILE__) === realpath ($_SERVER["SCRIPT_FILENAME"]))
	exit ("Do not access this file directly.");
/**/
if (!class_exists ("c_ws_plugin__s2member_pro_paypal_responses"))
	{
		/**
		* PayPal® Pro Form responses.
		*
		* @package s2Member\PayPal
		* @since 1.5
		*/
		class c_ws_plugin__s2member_pro_paypal_responses
			{
				/**
				* Creates response divs after Cancellation processing.
				*
				* @package s2Member\PayPal
				* @since 1.5
				*
				* @param array $attr An array of Pro Form Attributes.
				* @return array An array of response details.
				*/
				public static function paypal_cancellation_response ($attr = FALSE)
					{
						$_response = $GLOBALS["ws_plugin__s2member_pro_paypal_cancellation_response"];
						/**/
						$_response = (!$_response) ? c_ws_plugin__s2member_pro_paypal_responses::paypal_form_attr_validation_errors ($attr) : $_response;
						/**/
						if ($_response && ($error = $_response["error"])) /* Error reporting. */
							{
								$response = '<div id="s2member-pro-paypal-form-response" class="s2member-pro-paypal-form-response-error s2member-pro-paypal-cancellation-form-response-error">';
								$response .= $_response["response"];
								$response .= '</div>';
							}
						else if ($_response) /* Otherwise, we treat this as an informational response. */
							{
								$response = '<div id="s2member-pro-paypal-form-response" class="s2member-pro-paypal-form-response-info s2member-pro-paypal-cancellation-form-response-info">';
								$response .= $_response["response"];
								$response .= '</div>';
							}
						/**/
						return array ("response" => $response, "error" => $error);
					}
				/**
				* Creates response divs after Update processing.
				*
				* @package s2Member\PayPal
				* @since 1.5
				*
				* @param array $attr An array of Pro Form Attributes.
				* @return array An array of response details.
				*/
				public static function paypal_update_response ($attr = FALSE)
					{
						$_response = $GLOBALS["ws_plugin__s2member_pro_paypal_update_response"];
						/**/
						$_response = (!$_response) ? c_ws_plugin__s2member_pro_paypal_responses::paypal_form_attr_validation_errors ($attr) : $_response;
						/**/
						if ($_response && ($error = $_response["error"])) /* Error reporting. */
							{
								$response = '<div id="s2member-pro-paypal-form-response" class="s2member-pro-paypal-form-response-error s2member-pro-paypal-update-form-response-error">';
								$response .= $_response["response"];
								$response .= '</div>';
							}
						else if ($_response) /* Otherwise, we treat this as an informational response. */
							{
								$response = '<div id="s2member-pro-paypal-form-response" class="s2member-pro-paypal-form-response-info s2member-pro-paypal-update-form-response-info">';
								$response .= $_response["response"];
								$response .= '</div>';
							}
						/**/
						return array ("response" => $response, "error" => $error);
					}
				/**
				* Creates response divs after Registration processing.
				*
				* @package s2Member\PayPal
				* @since 1.5
				*
				* @param array $attr An array of Pro Form Attributes.
				* @return array An array of response details.
				*/
				public static function paypal_registration_response ($attr = FALSE)
					{
						$_response = $GLOBALS["ws_plugin__s2member_pro_paypal_registration_response"];
						/**/
						$_response = (!$_response) ? c_ws_plugin__s2member_pro_paypal_responses::paypal_form_attr_validation_errors ($attr) : $_response;
						/**/
						if ($_response && ($error = $_response["error"])) /* Error reporting. */
							{
								$response = '<div id="s2member-pro-paypal-form-response" class="s2member-pro-paypal-form-response-error s2member-pro-paypal-registration-form-response-error">';
								$response .= $_response["response"];
								$response .= '</div>';
							}
						else if ($_response) /* Otherwise, we treat this as an informational response. */
							{
								$response = '<div id="s2member-pro-paypal-form-response" class="s2member-pro-paypal-form-response-info s2member-pro-paypal-registration-form-response-info">';
								$response .= $_response["response"];
								$response .= '</div>';
							}
						/**/
						return array ("response" => $response, "error" => $error);
					}
				/**
				* Creates response divs after Specific Post/Page checkout processing.
				*
				* @package s2Member\PayPal
				* @since 1.5
				*
				* @param array $attr An array of Pro Form Attributes.
				* @return array An array of response details.
				*/
				public static function paypal_sp_checkout_response ($attr = FALSE)
					{
						$_response = $GLOBALS["ws_plugin__s2member_pro_paypal_sp_checkout_response"];
						/**/
						$_response = (!$_response) ? c_ws_plugin__s2member_pro_paypal_responses::paypal_form_attr_validation_errors ($attr) : $_response;
						/**/
						if ($_response && ($error = $_response["error"])) /* Error reporting. */
							{
								$response = '<div id="s2member-pro-paypal-form-response" class="s2member-pro-paypal-form-response-error s2member-pro-paypal-sp-checkout-form-response-error">';
								$response .= $_response["response"];
								$response .= '</div>';
							}
						else if ($_response) /* Otherwise, we treat this as an informational response. */
							{
								$response = '<div id="s2member-pro-paypal-form-response" class="s2member-pro-paypal-form-response-info s2member-pro-paypal-sp-checkout-form-response-info">';
								$response .= $_response["response"];
								$response .= '</div>';
							}
						/**/
						return array ("response" => $response, "error" => $error);
					}
				/**
				* Creates response divs after Membership checkout processing.
				*
				* @package s2Member\PayPal
				* @since 1.5
				*
				* @param array $attr An array of Pro Form Attributes.
				* @return array An array of response details.
				*/
				public static function paypal_checkout_response ($attr = FALSE)
					{
						$_response = $GLOBALS["ws_plugin__s2member_pro_paypal_checkout_response"];
						/**/
						$_response = (!$_response) ? c_ws_plugin__s2member_pro_paypal_responses::paypal_form_attr_validation_errors ($attr) : $_response;
						/**/
						if ($_response && ($error = $_response["error"])) /* Error reporting. */
							{
								$response = '<div id="s2member-pro-paypal-form-response" class="s2member-pro-paypal-form-response-error s2member-pro-paypal-checkout-form-response-error">';
								$response .= $_response["response"];
								$response .= '</div>';
							}
						else if ($_response) /* Otherwise, we treat this as an informational response. */
							{
								$response = '<div id="s2member-pro-paypal-form-response" class="s2member-pro-paypal-form-response-info s2member-pro-paypal-checkout-form-response-info">';
								$response .= $_response["response"];
								$response .= '</div>';
							}
						/**/
						return array ("response" => $response, "error" => $error);
					}
				/**
				* Validates the configuration of API Credentials.
				*
				* Free Registration Forms do NOT require API Credentials.
				*
				* @package s2Member\PayPal
				* @since 1.5
				*
				* @param array $attr An array of Pro Form Attributes.
				* @return null|array Null if there are no errors, else a response array.
				*/
				public static function paypal_form_api_validation_errors ($attr = FALSE)
					{
						if (!$GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["paypal_business"])
							$response = array ("response" => 'PayPal® configuration error. Please configure your PayPal® Email Address.', "error" => true);
						/**/
						else if (!$GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["paypal_api_username"])
							$response = array ("response" => 'PayPal® configuration error. Your PayPal® API Username is not yet configured.', "error" => true);
						/**/
						else if (!$GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["paypal_api_password"])
							$response = array ("response" => 'PayPal® configuration error. Your PayPal® API Password is not yet configured.', "error" => true);
						/**/
						else if (!$GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["paypal_api_signature"])
							$response = array ("response" => 'PayPal® configuration error. Your PayPal® API Signature is not yet configured.', "error" => true);
						/**/
						return (empty ($response) || !empty ($attr["register"])) ? null : $response;
					}
				/**
				* Validates the configuration of the current form.
				*
				* Free Registration Forms do NOT require API Credentials.
				*
				* @package s2Member\PayPal
				* @since 1.5
				*
				* @param array $attr An array of Pro Form Attributes.
				* @return null|array Null if there are no errors, else a response array.
				*/
				public static function paypal_form_attr_validation_errors ($attr = FALSE)
					{
						if (!($response = c_ws_plugin__s2member_pro_paypal_responses::paypal_form_api_validation_errors ($attr)) || !empty ($attr["register"]))
							{
								if ($attr["cancel"]) /* Special form for Cancellations. User/Member must be logged in. */
									{
										if (!is_user_logged_in ())
											$response = array ("response" => 'You must <a href="' . esc_attr (wp_login_url ($_SERVER["REQUEST_URI"])) . '" rel="nofollow">log in</a> to cancel your account.', "error" => true);
										/**/
										else if (!is_object ($user = wp_get_current_user ()) || !($user_id = $user->ID) || !($subscr_id = get_user_option ("s2member_subscr_id", $user_id)))
											$response = array ("response" => 'Nothing to cancel. You\'re NOT a paid Member.', "error" => true);
										/**/
										else if (is_array ($paypal = array ("PROFILEID" => $subscr_id, "METHOD" => "GetRecurringPaymentsProfileDetails")))
											{
												if (!($paypal = c_ws_plugin__s2member_paypal_utilities::paypal_api_response ($paypal)) || !empty ($paypal["__error"]))
													{
														if ($paypal && !empty ($paypal["__error"]) && $paypal["L_ERRORCODE0"] === "11592") /* Subscription Profile? */
															$response = array ("response" => 'Please <a href="https://' . (($GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["paypal_sandbox"]) ? "www.sandbox.paypal.com" : "www.paypal.com") . '/cgi-bin/webscr?cmd=_subscr-find&amp;alias=' . urlencode ($GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["paypal_business"]) . '" rel="nofollow">log in at PayPal®</a> to cancel your Subscription.', "error" => true);
														/**/
														else /* Else there was no Recurring Profile on record. */
															$response = array ("response" => 'Nothing to cancel. You have NO recurring fees.', "error" => true);
													}
												/**/
												else if (!preg_match ("/^(Active|ActiveProfile|Suspended|SuspendedProfile)$/i", $paypal["STATUS"]))
													$response = array ("response" => 'Nothing to cancel. You have NO recurring fees.', "error" => true);
											}
									}
								/**/
								else if ($attr["update"]) /* Special form for Updates. User/Member must be logged in. */
									{
										if (!is_user_logged_in ())
											$response = array ("response" => 'You must <a href="' . esc_attr (wp_login_url ($_SERVER["REQUEST_URI"])) . '" rel="nofollow">log in</a> to update your billing information.', "error" => true);
										/**/
										else if (!is_object ($user = wp_get_current_user ()) || !($user_id = $user->ID) || !($subscr_id = get_user_option ("s2member_subscr_id", $user_id)))
											$response = array ("response" => 'Nothing to update. You\'re NOT a paid Member.', "error" => true);
										/**/
										else if (is_array ($paypal = array ("PROFILEID" => $subscr_id, "METHOD" => "GetRecurringPaymentsProfileDetails")))
											{
												if (!($paypal = c_ws_plugin__s2member_paypal_utilities::paypal_api_response ($paypal)) || !empty ($paypal["__error"]) || strlen ($paypal["ACCT"]) !== 4)
													{
														if ($paypal && empty ($paypal["__error"]) && strlen ($paypal["ACCT"]) !== 4) /* It's NOT associated with a credit card; they used PayPal®. */
															$response = array ("response" => 'Please <a href="https://' . (($GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["paypal_sandbox"]) ? "www.sandbox.paypal.com" : "www.paypal.com") . '/" rel="nofollow">log in at PayPal®</a> to update your billing information.', "error" => true);
														/**/
														else if ($paypal && !empty ($paypal["__error"]) && $paypal["L_ERRORCODE0"] === "11592") /* Subscription Profile? */
															$response = array ("response" => 'Please <a href="https://' . (($GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["paypal_sandbox"]) ? "www.sandbox.paypal.com" : "www.paypal.com") . '/" rel="nofollow">log in at PayPal®</a> to update your billing information.', "error" => true);
														/**/
														else /* Else there was no Recurring Profile on record. */
															$response = array ("response" => 'Nothing to update. You have NO recurring fees.', "error" => true);
													}
												/**/
												else if (!preg_match ("/^(Active|ActiveProfile|Suspended|SuspendedProfile)$/i", $paypal["STATUS"]))
													$response = array ("response" => 'Nothing to update. You have NO recurring fees.', "error" => true);
											}
									}
								/**/
								else if ($attr["register"]) /* Free Registration does not require attr validation. */
									{
										if (!is_string ($attr["level"]) || !is_numeric ($attr["level"]))
											$response = array ("response" => 'Invalid form configuration. Missing "level" attribute. Membership Level. Must be numeric [0-' . esc_html ($GLOBALS["WS_PLUGIN__"]["s2member"]["c"]["levels"]) . '].', "error" => true);
										/**/
										else if ($attr["level"] < 0 || $attr["level"] > $GLOBALS["WS_PLUGIN__"]["s2member"]["c"]["levels"])
											$response = array ("response" => 'Invalid form configuration. Invalid "level" attribute. Membership Level. Must be numeric [0-' . esc_html ($GLOBALS["WS_PLUGIN__"]["s2member"]["c"]["levels"]) . '].', "error" => true);
										/**/
										else if ($attr["ccaps"] && (!is_string ($attr["ccaps"]) || (preg_replace ("/^-all[\r\n\t\s;,]*/", "", str_replace ("+", "", $attr["ccaps"])) && !preg_match ("/^([a-z_0-9,]+)$/", preg_replace ("/^-all[\r\n\t\s;,]*/", "", str_replace ("+", "", $attr["ccaps"]))))))
											$response = array ("response" => 'Invalid form configuration. Invalid "ccaps" attribute. Custom Capabilities. When provided, must be all lowercase [a-z_0-9,]. A preceding `-all,` directive is also acceptable.', "error" => true);
										/**/
										else if ($attr["tp"] && (!is_string ($attr["tp"]) || !is_numeric ($attr["tp"])))
											$response = array ("response" => 'Invalid form configuration. Invalid "tp" attribute. The Trial Period. When provided, must be numeric.', "error" => true);
										/**/
										else if ($attr["tp"] && $attr["tp"] < 1)
											$response = array ("response" => 'Invalid form configuration. Invalid "tp" attribute. The Trial Period. When provided, must be >= 1.', "error" => true);
										/**/
										else if ($attr["tp"] && (!$attr["tt"] || !is_string ($attr["tt"])))
											$response = array ("response" => 'Invalid form configuration. Missing "tt" attribute. The Trial Term. When "tp" is provided, "tt" ( Trial Term ) must be one of D,W,M,Y.', "error" => true);
										/**/
										else if ($attr["tp"] && !preg_match ("/[DWMY]/", $attr["tt"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "tt" attribute. The Trial Term. When "tp" is provided, "tt" ( Trial Term ) must be one of D,W,M,Y.', "error" => true);
										/**/
										else if ($attr["custom"] && (!is_string ($attr["custom"]) || !preg_match ("/^" . preg_quote (preg_replace ("/\:([0-9]+)$/", "", $_SERVER["HTTP_HOST"]), "/") . "/i", $attr["custom"])))
											$response = array ("response" => 'Invalid form configuration. Invalid "custom" attribute. When provided, must start with your domain name.', "error" => true);
									}
								/**/
								else if ($attr["sp"]) /* Validation routines for Specific Post/Page checkout forms. */
									{
										if (!$attr["ids"] || !is_string ($attr["ids"]))
											$response = array ("response" => 'Invalid form configuration. Missing "ids" attribute. Must contain comma-delimited Post/Page IDs.', "error" => true);
										/**/
										else if (!preg_match ("/^([0-9,]+)$/", $attr["ids"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "ids" attribute. Must contain comma-delimited Post/Page IDs. Must contain [0-9,] only.', "error" => true);
										/**/
										else if (!$attr["exp"] || !is_string ($attr["exp"]))
											$response = array ("response" => 'Invalid form configuration. Missing "exp" attribute. Specific Post/Page Expiration ( in hours ). Must be numeric.', "error" => true);
										/**/
										else if (!is_numeric ($attr["exp"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "exp" attribute. Specific Post/Page Expiration ( in hours ). Must be numeric.', "error" => true);
										/**/
										else if ($attr["exp"] < 1)
											$response = array ("response" => 'Invalid form configuration. Invalid "exp" attribute. Specific Post/Page Expiration ( in hours ). Must be >= 1.', "error" => true);
										/**/
										else if ($attr["exp"] > 43800)
											$response = array ("response" => 'Invalid form configuration. Invalid "exp" attribute. Specific Post/Page Expiration ( in hours ). Must be <= 43800.', "error" => true);
										/**/
										else if (!$attr["sp_ids_exp"] || !is_string ($attr["sp_ids_exp"]))
											$response = array ("response" => 'Invalid form configuration. Missing "sp_ids_exp" internal attribute. Unknown error, please contact Support.', "error" => true);
										/**/
										else if (!preg_match ($GLOBALS["WS_PLUGIN__"]["s2member"]["c"]["sp_access_item_number_regex"], $attr["sp_ids_exp"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "sp_ids_exp" internal attribute. Unknown error, please contact Support.', "error" => true);
										/**/
										else if (!$attr["desc"] || !is_string ($attr["desc"]))
											$response = array ("response" => 'Invalid form configuration. Missing "desc" attribute. Please provide a Description for this form.', "error" => true);
										/**/
										else if (strlen ($attr["desc"]) > 100) /* Actually, this can be 127 chars; but we need plenty of room for s2Member's coupon info. */
											$response = array ("response" => 'Invalid form configuration. Your "desc" ( Description ) attribute must be <= 100 characters long.', "error" => true);
										/**/
										else if (!$attr["custom"] || !is_string ($attr["custom"]))
											$response = array ("response" => 'Invalid form configuration. Missing "custom" attribute. Must start with your domain name.', "error" => true);
										/**/
										else if (!preg_match ("/^" . preg_quote (preg_replace ("/\:([0-9]+)$/", "", $_SERVER["HTTP_HOST"]), "/") . "/i", $attr["custom"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "custom" attribute. Must start with your domain name.', "error" => true);
										/**/
										else if (!$attr["cc"] || !is_string ($attr["cc"]))
											$response = array ("response" => 'Invalid form configuration. Missing "cc" attribute. Must be a 3 character Currency Code.', "error" => true);
										/**/
										else if (strlen ($attr["cc"]) !== 3)
											$response = array ("response" => 'Invalid form configuration. Invalid "cc" attribute. Must be a 3 character Currency Code.', "error" => true);
										/**/
										else if (!strlen ($attr["dg"]) || !is_string ($attr["dg"]))
											$response = array ("response" => 'Invalid form configuration. Missing "dg" attribute. Digital indicator. Must be numeric [0-1].', "error" => true);
										/**/
										else if ($attr["dg"] < 0 || $attr["dg"] > 1)
											$response = array ("response" => 'Invalid form configuration. Invalid "dg" attribute. Digital indicator. Must be numeric [0-1].', "error" => true);
										/**/
										else if (!strlen ($attr["ns"]) || !is_string ($attr["ns"]))
											$response = array ("response" => 'Invalid form configuration. Missing "ns" attribute. Shipping configuration. Must be numeric [0-2].', "error" => true);
										/**/
										else if ($attr["ns"] < 0 || $attr["ns"] > 2)
											$response = array ("response" => 'Invalid form configuration. Invalid "ns" attribute. Shipping configuration. Must be numeric [0-2].', "error" => true);
										/**/
										else if ($attr["dg"] && $attr["ns"] !== "1")
											$response = array ("response" => 'Invalid form configuration. Invalid "ns" attribute. Shipping configuration. Must be 1 with "dg" ( digital ) items.', "error" => true);
										/**/
										else if ($attr["lc"] && strlen ($attr["lc"]) !== 2)
											$response = array ("response" => 'Invalid form configuration. Invalid "lc" attribute. Locale Code. When provided, must be a 2 character country code.', "error" => true);
										/**/
										else if (!$attr["ra"] || !is_string ($attr["ra"]))
											$response = array ("response" => 'Invalid form configuration. Missing "ra" attribute. The Regular Amount. Must be >= 0.01.', "error" => true);
										/**/
										else if (!is_numeric ($attr["ra"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "ra" attribute. The Regular Amount. Must be numeric.', "error" => true);
										/**/
										else if ($attr["ra"] < 0.01)
											$response = array ("response" => 'Invalid form configuration. Invalid "ra" attribute. The Regular Amount. Must be >= 0.01.', "error" => true);
										/**/
										else if ($attr["ra"] > 10000.00)
											$response = array ("response" => 'Invalid form configuration. Invalid "ra" attribute. The Regular Amount. Must be <= 10000.00.', "error" => true);
									}
								/**/
								else /* Validation routines for Member Level checkout forms. This is the default functionality. */
									{
										if ($attr["modify"] && !is_user_logged_in ()) /* Must be logged in before a modification can take place. */
											$response = array ("response" => 'You must <a href="' . esc_attr (wp_login_url ($_SERVER["REQUEST_URI"])) . '" rel="nofollow">login</a> to update your billing plan.', "error" => true);
										/**/
										else if ($attr["level"] === "*" && !is_user_logged_in ()) /* Must be logged in before purchasing. */
											$response = array ("response" => 'You must <a href="' . esc_attr (wp_login_url ($_SERVER["REQUEST_URI"])) . '" rel="nofollow">login</a> before making this purchase.', "error" => true);
										/**/
										else if ((!$attr["level"] || !is_string ($attr["level"]) || !is_numeric ($attr["level"])) && $attr["level"] !== "*")
											$response = array ("response" => 'Invalid form configuration. Missing "level" attribute. Membership Level. Must be numeric [1-' . esc_html ($GLOBALS["WS_PLUGIN__"]["s2member"]["c"]["levels"]) . '], or an asterisk (*).', "error" => true);
										/**/
										else if (($attr["level"] < 1 || $attr["level"] > $GLOBALS["WS_PLUGIN__"]["s2member"]["c"]["levels"]) && $attr["level"] !== "*")
											$response = array ("response" => 'Invalid form configuration. Invalid "level" attribute. Membership Level. Must be numeric [1-' . esc_html ($GLOBALS["WS_PLUGIN__"]["s2member"]["c"]["levels"]) . '], or an asterisk (*).', "error" => true);
										/**/
										else if ($attr["ccaps"] && (!is_string ($attr["ccaps"]) || (preg_replace ("/^-all[\r\n\t\s;,]*/", "", str_replace ("+", "", $attr["ccaps"])) && !preg_match ("/^([a-z_0-9,]+)$/", preg_replace ("/^-all[\r\n\t\s;,]*/", "", str_replace ("+", "", $attr["ccaps"]))))))
											$response = array ("response" => 'Invalid form configuration. Invalid "ccaps" attribute. Custom Capabilities. When provided, must be all lowercase [a-z_0-9,]. A preceding `-all,` directive is also acceptable.', "error" => true);
										/**/
										else if ($attr["level"] === "*" && (!is_string ($attr["ccaps"]) || !preg_replace ("/^-all[\r\n\t\s;,]*/", "", str_replace ("+", "", $attr["ccaps"])) || !preg_match ("/^([a-z_0-9,]+)$/", preg_replace ("/^-all[\r\n\t\s;,]*/", "", str_replace ("+", "", $attr["ccaps"])))))
											$response = array ("response" => 'Invalid form configuration. Missing or invalid "ccaps" attribute. When "level" is "*" for ( Independent Custom Capabilities ), "ccaps" is required. All lowercase [a-z_0-9,]. A preceding `-all,` directive is also acceptable.', "error" => true);
										/**/
										else if (!$attr["desc"] || !is_string ($attr["desc"]))
											$response = array ("response" => 'Invalid form configuration. Missing "desc" attribute. Please provide a Description for this form.', "error" => true);
										/**/
										else if (strlen ($attr["desc"]) > 100) /* Actually, this can be 127 chars; but we need plenty of room for s2Member's coupon info. */
											$response = array ("response" => 'Invalid form configuration. Your "desc" ( Description ) attribute must be <= 100 characters long.', "error" => true);
										/**/
										else if (!$attr["custom"] || !is_string ($attr["custom"]))
											$response = array ("response" => 'Invalid form configuration. Missing "custom" attribute. Must start with your domain name.', "error" => true);
										/**/
										else if (!preg_match ("/^" . preg_quote (preg_replace ("/\:([0-9]+)$/", "", $_SERVER["HTTP_HOST"]), "/") . "/i", $attr["custom"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "custom" attribute. Must start with matching domain.', "error" => true);
										/**/
										else if (!$attr["cc"] || !is_string ($attr["cc"]))
											$response = array ("response" => 'Invalid form configuration. Missing "cc" attribute. Must be a 3 character Currency Code.', "error" => true);
										/**/
										else if (strlen ($attr["cc"]) !== 3)
											$response = array ("response" => 'Invalid form configuration. Invalid "cc" attribute. Must be a 3 character Currency Code.', "error" => true);
										/**/
										else if (!strlen ($attr["dg"]) || !is_string ($attr["dg"]))
											$response = array ("response" => 'Invalid form configuration. Missing "dg" attribute. Digital indicator. Must be numeric [0-1].', "error" => true);
										/**/
										else if ($attr["dg"] < 0 || $attr["dg"] > 1)
											$response = array ("response" => 'Invalid form configuration. Invalid "dg" attribute. Digital indicator. Must be numeric [0-1].', "error" => true);
										/**/
										else if (!strlen ($attr["ns"]) || !is_string ($attr["ns"]))
											$response = array ("response" => 'Invalid form configuration. Missing "ns" attribute. Shipping configuration. Must be numeric [0-2].', "error" => true);
										/**/
										else if ($attr["ns"] < 0 || $attr["ns"] > 2)
											$response = array ("response" => 'Invalid form configuration. Invalid "ns" attribute. Shipping configuration. Must be numeric [0-2].', "error" => true);
										/**/
										else if ($attr["dg"] && $attr["ns"] !== "1")
											$response = array ("response" => 'Invalid form configuration. Invalid "ns" attribute. Shipping configuration. Must be 1 with "dg" ( digital ) items.', "error" => true);
										/**/
										else if ($attr["lc"] && strlen ($attr["lc"]) !== 2)
											$response = array ("response" => 'Invalid form configuration. Invalid "lc" attribute. Locale Code. When provided, must be a 2 character country code.', "error" => true);
										/**/
										else if ($attr["tp"] && (!is_string ($attr["tp"]) || !is_numeric ($attr["tp"])))
											$response = array ("response" => 'Invalid form configuration. Invalid "tp" attribute. The Trial Period. When provided, must be numeric.', "error" => true);
										/**/
										else if ($attr["tp"] && $attr["tp"] < 1)
											$response = array ("response" => 'Invalid form configuration. Invalid "tp" attribute. The Trial Period. When provided, must be >= 1.', "error" => true);
										/**/
										else if ($attr["tp"] && (!$attr["tt"] || !is_string ($attr["tt"])))
											$response = array ("response" => 'Invalid form configuration. Missing "tt" attribute. The Trial Term. When "tp" is provided, "tt" ( Trial Term ) must be one of D,W,M,Y.', "error" => true);
										/**/
										else if ($attr["tp"] && !preg_match ("/[DWMY]/", $attr["tt"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "tt" attribute. The Trial Term. When "tp" is provided, "tt" ( Trial Term ) must be one of D,W,M,Y.', "error" => true);
										/**/
										else if ($attr["tp"] && $attr["tt"] === "D" && $attr["tp"] > 365)
											$response = array ("response" => 'Invalid form configuration. Invalid "tt, tp" attributes. The "tt" ( Trial Term ) attribute is "D", and "tp" ( Trial Period ) > 365.', "error" => true);
										/**/
										else if ($attr["tp"] && $attr["tt"] === "W" && $attr["tp"] > 52)
											$response = array ("response" => 'Invalid form configuration. Invalid "tt, tp" attributes. The "tt" ( Trial Term ) attribute is "W", and "tp" ( Trial Period ) > 52.', "error" => true);
										/**/
										else if ($attr["tp"] && $attr["tt"] === "M" && $attr["tp"] > 12)
											$response = array ("response" => 'Invalid form configuration. Invalid "tt, tp" attributes. The "tt" ( Trial Term ) attribute is "M", and "tp" ( Trial Period ) > 12.', "error" => true);
										/**/
										else if ($attr["tp"] && $attr["tt"] === "Y" && $attr["tp"] > 1)
											$response = array ("response" => 'Invalid form configuration. Invalid "tt, tp" attributes. The "tt" ( Trial Term ) attribute is "Y", and "tp" ( Trial Period ) > 1.', "error" => true);
										/**/
										else if ($attr["tp"] && $attr["ta"] && !is_numeric ($attr["ta"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "ta" attribute. The Trial Amount. When provided, must be numeric.', "error" => true);
										/**/
										else if ($attr["tp"] && $attr["ta"] && $attr["ta"] < 0.00)
											$response = array ("response" => 'Invalid form configuration. Invalid "ta" attribute. The Trial Amount. When provided, must be >= 0.00.', "error" => true);
										/**/
										else if ($attr["tp"] && $attr["ta"] && $attr["ta"] > 10000.00)
											$response = array ("response" => 'Invalid form configuration. Invalid "ta" attribute. The Trial Amount. When provided, must be <= 10000.00.', "error" => true);
										/**/
										else if (!$attr["rp"] || !is_string ($attr["rp"]))
											$response = array ("response" => 'Invalid form configuration. Missing "rp" attribute. The Regular Period. Must be >= 1.', "error" => true);
										/**/
										else if (!is_numeric ($attr["rp"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "rp" attribute. The Regular Period. Must be numeric.', "error" => true);
										/**/
										else if ($attr["rp"] < 1)
											$response = array ("response" => 'Invalid form configuration. Invalid "rp" attribute. The Regular Period. Must be >= 1.', "error" => true);
										/**/
										else if (!$attr["rt"] || !is_string ($attr["rt"]))
											$response = array ("response" => 'Invalid form configuration. Missing "rt" attribute. The Regular Term. Must be one of D,W,M,Y,L.', "error" => true);
										/**/
										else if (!preg_match ("/[DWMYL]/", $attr["rt"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "rt" attribute. The Regular Term. Must be one of D,W,M,Y,L.', "error" => true);
										/**/
										else if ($attr["rt"] === "D" && $attr["rp"] > 365 && $attr["rr"] !== "BN")
											$response = array ("response" => 'Invalid form configuration. Invalid "rt, rp, rr" attributes. The "rt" ( Regular Term ) attribute is "D", "rp" ( Regular Period ) > 365, and "rr" is not "BN" ( Buy Now ).', "error" => true);
										/**/
										else if ($attr["rt"] === "W" && $attr["rp"] > 52 && $attr["rr"] !== "BN")
											$response = array ("response" => 'Invalid form configuration. Invalid "rt, rp, rr" attributes. The "rt" ( Regular Term ) attribute is "W", "rp" ( Regular Period ) > 52, and "rr" is not "BN" ( Buy Now ).', "error" => true);
										/**/
										else if ($attr["rt"] === "M" && $attr["rp"] > 12 && $attr["rr"] !== "BN")
											$response = array ("response" => 'Invalid form configuration. Invalid "rt, rp, rr" attributes. The "rt" ( Regular Term ) attribute is "M", "rp" ( Regular Period ) > 12, and "rr" is not "BN" ( Buy Now ).', "error" => true);
										/**/
										else if ($attr["rt"] === "Y" && $attr["rp"] > 5 && $attr["rr"] !== "BN")
											$response = array ("response" => 'Invalid form configuration. Invalid "rt, rp, rr" attributes. The "rt" ( Regular Term ) attribute is "Y", "rp" ( Regular Period ) > 5, and "rr" is not "BN" ( Buy Now ).', "error" => true);
										/**/
										else if ($attr["rt"] === "Y" && $attr["rp"] > 1 && $attr["rr"] !== "BN")
											$response = array ("response" => 'Invalid form configuration. Invalid "rt, rp, rr" attributes. The "rt" ( Regular Term ) attribute is "Y", "rp" ( Regular Period ) > 1, and "rr" is not "BN" ( Buy Now ).', "error" => true);
										/**/
										else if ($attr["rt"] === "L" && $attr["rp"] > 1)
											$response = array ("response" => 'Invalid form configuration. Invalid "rt, rp" attributes. The "rt" ( Regular Term ) attribute is "L" ( Lifetime ), and "rp" ( Regular Period ) > 1.', "error" => true);
										/**/
										else if ($attr["rt"] === "L" && $attr["rr"] !== "BN")
											$response = array ("response" => 'Invalid form configuration. Invalid "rt, rr" attributes. The "rt" ( Regular Term ) attribute is "L" ( Lifetime ), and "rr" is not "BN" ( Buy Now ).', "error" => true);
										/**/
										else if (!$attr["level_ccaps_eotper"] || !is_string ($attr["level_ccaps_eotper"]))
											$response = array ("response" => 'Invalid form configuration. Missing "level_ccaps_eotper" attribute. Unknown error, please contact Support.', "error" => true);
										/**/
										else if ($attr["level"] !== "*" && !preg_match ($GLOBALS["WS_PLUGIN__"]["s2member"]["c"]["membership_item_number_w_level_regex"], $attr["level_ccaps_eotper"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "level_ccaps_eotper" attribute. Unknown error, please contact Support.', "error" => true);
										/**/
										else if ($attr["level"] === "*" && !preg_match ($GLOBALS["WS_PLUGIN__"]["s2member"]["c"]["membership_item_number_wo_level_regex"], $attr["level_ccaps_eotper"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "level_ccaps_eotper" attribute. Unknown error, please contact Support.', "error" => true);
										/**/
										else if (!$attr["ra"] || !is_string ($attr["ra"]))
											$response = array ("response" => 'Invalid form configuration. Missing "ra" attribute. The Regular Amount. Must be >= 0.01.', "error" => true);
										/**/
										else if (!is_numeric ($attr["ra"]))
											$response = array ("response" => 'Invalid form configuration. Invalid "ra" attribute. The Regular Amount. Must be numeric.', "error" => true);
										/**/
										else if ($attr["ra"] < 0.01)
											$response = array ("response" => 'Invalid form configuration. Invalid "ra" attribute. The Regular Amount. Must be >= 0.01.', "error" => true);
										/**/
										else if ($attr["ra"] > 10000.00)
											$response = array ("response" => 'Invalid form configuration. Invalid "ra" attribute. The Regular Amount. Must be <= 10000.00.', "error" => true);
										/**/
										else if ($attr["rr"] && (!is_string ($attr["rr"]) || !preg_match ("/^([0-1]|BN)$/", $attr["rr"])))
											$response = array ("response" => 'Invalid form configuration. Invalid "rr" attribute. Regular Recurring. When provided, must be 0, 1, or BN.', "error" => true);
										/**/
										else if ($attr["rr"] === "BN" && $attr["tp"])
											$response = array ("response" => 'Invalid form configuration. Invalid "rr, tp" attributes. The "rr" ( Regular Recurring ) attribute is "BN" ( Buy Now ), and "tp" ( Trial Period ) is not "0".', "error" => true);
										/**/
										else if ($attr["level"] === "*" && $attr["rr"] !== "BN")
											$response = array ("response" => 'Invalid form configuration. Invalid "level, rr" attributes. The "level" ( Level ) attribute is "*" for ( Independent Custom Capabilities ), and "rr" is not "BN" ( Buy Now ).', "error" => true);
										/**/
										else if ($attr["ta"] === $attr["ra"] && $attr["tp"] === $attr["rp"] && $attr["tt"] === $attr["rt"])
											$response = array ("response" => 'Invalid form configuration. Invalid "ta, tp, tt" attributes. Trial Period. When provided, these cannot be exactly the same as your "ra, rp, rt" attributes.', "error" => true);
										/**/
										else if ($attr["rrt"] && (!is_string ($attr["rrt"]) || !is_numeric ($attr["rrt"])))
											$response = array ("response" => 'Invalid form configuration. Invalid "rrt" attribute. Recurring Times ( fixed ). When provided, must be numeric.', "error" => true);
										/**/
										else if ($attr["rrt"] && $attr["rrt"] < 1)
											$response = array ("response" => 'Invalid form configuration. Invalid "rrt" attribute. Recurring Times ( fixed ). When provided, must be >= 1.', "error" => true);
										/**/
										else if ($attr["rrt"] && $attr["rr"] !== "1")
											$response = array ("response" => 'Invalid form configuration. Invalid "rr, rrt" attributes. When "rrt" ( Recurring Times ) is provided, "rr" ( Regular Recurring ) must be 1.', "error" => true);
										/****/
										else if (($attr["rr"] === "0" || $attr["rr"] === "1") && (!is_string ($attr["rra"]) || !is_numeric ($attr["rra"])))
											$response = array ("response" => 'Invalid form configuration. Invalid "rr, rra" attributes. When "rr" ( Regular Recurring ) is 0 or 1, "rra" ( Recurring Retry Attempts ) must be numeric.', "error" => true);
										/**/
										else if (($attr["rr"] === "0" || $attr["rr"] === "1") && $attr["rra"] < 0)
											$response = array ("response" => 'Invalid form configuration. Invalid "rr, rra" attributes. When "rr" ( Regular Recurring ) is 0 or 1, "rra" ( Recurring Retry Attempts ) must be >= 0.', "error" => true);
									}
							}
						/**/
						return (empty ($response)) ? null : $response;
					}
				/**
				* Validates different kinds of form submissions.
				*
				* Free Registration Forms do NOT require API Credentials.
				*
				* @package s2Member\PayPal
				* @since 1.5
				*
				* @param str $form The type of Pro Form being submitted.
				* @param array $s An array of data submitted through the Pro Form.
				* @return null|array Null if there are no errors, else a response array.
				*/
				public static function paypal_form_submission_validation_errors ($form = FALSE, $s = FALSE)
					{
						if (!($response = c_ws_plugin__s2member_pro_paypal_responses::paypal_form_api_validation_errors ()) || $form === "registration")
							{
								if ($form === "cancellation") /* Special form for Cancellations. User/Member must be logged in. */
									{
										if (!is_user_logged_in ())
											$response = array ("response" => 'You must <a href="' . esc_attr (wp_login_url ($_SERVER["REQUEST_URI"])) . '" rel="nofollow">log in</a> to cancel your account.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if ($s["attr"]["captcha"] && (!$s["recaptcha_challenge_field"] || !$s["recaptcha_response_field"] || !c_ws_plugin__s2member_utils_captchas::recaptcha_code_validates ($s["recaptcha_challenge_field"], $s["recaptcha_response_field"])))
											$response = array ("response" => 'Missing or invalid Security Code. Please try again.', "error" => true); /* Missing or invalid Captcha/Security Code. */
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if (is_object ($user = wp_get_current_user ()) && $user->ID && $user->has_cap ("administrator")) /* NOT for Administrators. */
											$response = array ("response" => 'Unable to process. You are an Administrator. Stopping here for security. Otherwise, an Administrator could lose access.', "error" => true);
									}
								/**/
								else if ($form === "update") /* Special form for Updates. User/Member must be logged in. */
									{
										if (!is_user_logged_in ())
											$response = array ("response" => 'You must <a href="' . esc_attr (wp_login_url ($_SERVER["REQUEST_URI"])) . '" rel="nofollow">log in</a> to update your billing information.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if (is_object ($user = wp_get_current_user ()) && $user->ID && $user->has_cap ("administrator")) /* NOT for Administrators. */
											$response = array ("response" => 'Unable to process. You are an Administrator. Stopping here for security. Otherwise, an Administrator could lose access.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if (!$s["card_type"] || !is_string ($s["card_type"]))
											$response = array ("response" => 'Missing Card Type ( Billing Method ). Please try again.', "error" => true);
										/**/
										else if (!in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo", "PayPal")))
											$response = array ("response" => 'Invalid Card Type ( Billing Method ). Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["card_number"] || !is_string ($s["card_number"])))
											$response = array ("response" => 'Missing Card Number. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["card_expiration"] || !is_string ($s["card_expiration"])))
											$response = array ("response" => 'Missing Card Expiration Date ( mm/yyyy ). Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && !preg_match ("/^[0-9]{2}\/[0-9]{4}$/", $s["card_expiration"]))
											$response = array ("response" => 'Invalid Card Expiration Date. Must be in this format ( mm/yyyy ). Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["card_verification"] || !is_string ($s["card_verification"])))
											$response = array ("response" => 'Missing Card Verification Code. It\'s on the back of your Card. 3-4 digits. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Maestro", "Solo")) && (!$s["card_start_date_issue_number"] || !is_string ($s["card_start_date_issue_number"])))
											$response = array ("response" => 'Missing Card Start Date, or Issue #. Required for Maestro/Solo. Please try again.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["street"] || !is_string ($s["street"])))
											$response = array ("response" => 'Missing Street Address. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["city"] || !is_string ($s["city"])))
											$response = array ("response" => 'Missing City/Town. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["state"] || !is_string ($s["state"])))
											$response = array ("response" => 'Missing State/Province. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["country"] || !is_string ($s["country"])))
											$response = array ("response" => 'Missing Country. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["zip"] || !is_string ($s["zip"])))
											$response = array ("response" => 'Missing Postal/Zip Code. Please try again.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if ($s["attr"]["captcha"] && (!$s["recaptcha_challenge_field"] || !$s["recaptcha_response_field"] || !c_ws_plugin__s2member_utils_captchas::recaptcha_code_validates ($s["recaptcha_challenge_field"], $s["recaptcha_response_field"])))
											$response = array ("response" => 'Missing or invalid Security Code. Please try again.', "error" => true); /* Missing or invalid Captcha/Security Code. */
									}
								/**/
								else if ($form === "registration") /* Validation routines for free Registration forms. */
									{
										if ($GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["custom_reg_names"] && (!$s["first_name"] || !is_string ($s["first_name"])))
											$response = array ("response" => 'Missing First Name. Please try again.', "error" => true);
										/**/
										else if ($GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["custom_reg_names"] && (!$s["last_name"] || !is_string ($s["last_name"])))
											$response = array ("response" => 'Missing Last Name. Please try again.', "error" => true);
										/**/
										else if (!$s["email"] || !is_string ($s["email"]))
											$response = array ("response" => 'Missing or invalid Email Address. Please try again.', "error" => true);
										/**/
										else if (!is_email ($s["email"]))
											$response = array ("response" => 'Invalid Email Address. Please try again.', "error" => true);
										/**/
										else if (email_exists ($s["email"]) && (!is_multisite () || !c_ws_plugin__s2member_utils_users::ms_user_login_email_can_join_blog ($s["username"], $s["email"])))
											$response = array ("response" => 'That Email Address is already in use. Please try again.', "error" => true);
										/**/
										else if (!$s["username"] || !is_string ($s["username"]))
											$response = array ("response" => 'Missing or invalid Username. Please try again.', "error" => true);
										/**/
										else if (!validate_username ($s["username"]))
											$response = array ("response" => 'Invalid Username. Please try again. Use ONLY lowercase alphanumerics.', "error" => true);
										/**/
										else if (username_exists ($s["username"]) && (!is_multisite () || !c_ws_plugin__s2member_utils_users::ms_user_login_email_can_join_blog ($s["username"], $s["email"])))
											$response = array ("response" => 'That Username is already in use. Please try again.', "error" => true);
										/**/
										else if (is_multisite () && !c_ws_plugin__s2member_utils_users::ms_user_login_email_can_join_blog ($s["username"], $s["email"]) && ($_response = wpmu_validate_user_signup ($s["username"], $s["email"])) && is_wp_error ($_errors = $_response["errors"]) && $_errors->get_error_message ())
											$response = array ("response" => $_errors->get_error_message (), "error" => true);
										/**/
										else if ((!$s["password1"] || !is_string ($s["password1"])) && $GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["custom_reg_password"])
											$response = array ("response" => 'Missing Password. Please try again.', "error" => true);
										/**/
										else if (strlen ($s["password1"]) < 6 && $GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["custom_reg_password"])
											$response = array ("response" => 'Invalid Password. Must be at least 6 characters. Please try again.', "error" => true);
										/**/
										else if (strlen ($s["password1"]) > 20 && $GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["custom_reg_password"])
											$response = array ("response" => 'Invalid Password. Max length is 20 characters. Please try again.', "error" => true);
										/**/
										else if ($s["password2"] !== $s["password1"] && $GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["custom_reg_password"])
											$response = array ("response" => 'Password fields do NOT match. Please try again.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if ($s["attr"]["captcha"] && (!$s["recaptcha_challenge_field"] || !$s["recaptcha_response_field"] || !c_ws_plugin__s2member_utils_captchas::recaptcha_code_validates ($s["recaptcha_challenge_field"], $s["recaptcha_response_field"])))
											$response = array ("response" => 'Missing or invalid Security Code. Please try again.', "error" => true); /* Missing or invalid Captcha/Security Code. */
									}
								/**/
								else if ($form === "sp-checkout") /* Validation routines for Specific Post/Page checkout forms. */
									{
										if (!$s["first_name"] || !is_string ($s["first_name"]))
											$response = array ("response" => 'Missing First Name. Please try again.', "error" => true);
										/**/
										else if (!$s["last_name"] || !is_string ($s["last_name"]))
											$response = array ("response" => 'Missing Last Name. Please try again.', "error" => true);
										/**/
										else if (!$s["email"] || !is_string ($s["email"]))
											$response = array ("response" => 'Missing or invalid Email Address. Please try again.', "error" => true);
										/**/
										else if (!is_email ($s["email"]))
											$response = array ("response" => 'Invalid Email Address. Please try again.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if (!$s["card_type"] || !is_string ($s["card_type"]))
											$response = array ("response" => 'Missing Card Type ( Billing Method ). Please try again.', "error" => true);
										/**/
										else if (!in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo", "PayPal")))
											$response = array ("response" => 'Invalid Card Type ( Billing Method ). Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["card_number"] || !is_string ($s["card_number"])))
											$response = array ("response" => 'Missing Card Number. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["card_expiration"] || !is_string ($s["card_expiration"])))
											$response = array ("response" => 'Missing Card Expiration Date ( mm/yyyy ). Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && !preg_match ("/^[0-9]{2}\/[0-9]{4}$/", $s["card_expiration"]))
											$response = array ("response" => 'Invalid Card Expiration Date. Must be in this format ( mm/yyyy ). Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["card_verification"] || !is_string ($s["card_verification"])))
											$response = array ("response" => 'Missing Card Verification Code. It\'s on the back of your Card. 3-4 digits. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Maestro", "Solo")) && (!$s["card_start_date_issue_number"] || !is_string ($s["card_start_date_issue_number"])))
											$response = array ("response" => 'Missing Card Start Date, or Issue #. Required for Maestro/Solo. Please try again.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["street"] || !is_string ($s["street"])))
											$response = array ("response" => 'Missing Street Address. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["city"] || !is_string ($s["city"])))
											$response = array ("response" => 'Missing City/Town. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["state"] || !is_string ($s["state"])))
											$response = array ("response" => 'Missing State/Province. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["country"] || !is_string ($s["country"])))
											$response = array ("response" => 'Missing Country. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["zip"] || !is_string ($s["zip"])))
											$response = array ("response" => 'Missing Postal/Zip Code. Please try again.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if ($s["attr"]["captcha"] && (!$s["recaptcha_challenge_field"] || !$s["recaptcha_response_field"] || !c_ws_plugin__s2member_utils_captchas::recaptcha_code_validates ($s["recaptcha_challenge_field"], $s["recaptcha_response_field"])))
											$response = array ("response" => 'Missing or invalid Security Code. Please try again.', "error" => true); /* Missing or invalid Captcha/Security Code. */
									}
								/**/
								else if ($form === "checkout") /* Validation routines for Member Level checkout forms. This is the default functionality. */
									{
										if ($s["attr"]["modify"] && !is_user_logged_in ())
											$response = array ("response" => 'You must <a href="' . esc_attr (wp_login_url ($_SERVER["REQUEST_URI"])) . '" rel="nofollow">log in</a> to modify your billing plan.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if ($s["attr"]["level"] === "*" && !is_user_logged_in ())
											$response = array ("response" => 'You must <a href="' . esc_attr (wp_login_url ($_SERVER["REQUEST_URI"])) . '" rel="nofollow">log in</a> before making this purchase.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if (is_user_logged_in () && is_object ($user = wp_get_current_user ()) && $user->ID && $user->has_cap ("administrator")) /* NOT for Administrators. */
											$response = array ("response" => 'Unable to process. You are an Administrator. Stopping here for security. Otherwise, an Administrator could lose access.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if (!$s["first_name"] || !is_string ($s["first_name"]))
											$response = array ("response" => 'Missing First Name. Please try again.', "error" => true);
										/**/
										else if (!$s["last_name"] || !is_string ($s["last_name"]))
											$response = array ("response" => 'Missing Last Name. Please try again.', "error" => true);
										/**/
										else if (!is_user_logged_in () && (!$s["email"] || !is_string ($s["email"])))
											$response = array ("response" => 'Missing or invalid Email Address. Please try again.', "error" => true);
										/**/
										else if (!is_user_logged_in () && !is_email ($s["email"]))
											$response = array ("response" => 'Invalid Email Address. Please try again.', "error" => true);
										/**/
										else if (!is_user_logged_in () && email_exists ($s["email"]) && (!is_multisite () || !c_ws_plugin__s2member_utils_users::ms_user_login_email_can_join_blog ($s["username"], $s["email"])))
											$response = array ("response" => 'That Email Address is already in use. Please try again.', "error" => true);
										/**/
										else if (!is_user_logged_in () && (!$s["username"] || !is_string ($s["username"])))
											$response = array ("response" => 'Missing or invalid Username. Please try again.', "error" => true);
										/**/
										else if (!is_user_logged_in () && !validate_username ($s["username"]))
											$response = array ("response" => 'Invalid Username. Please try again. Use ONLY lowercase alphanumerics.', "error" => true);
										/**/
										else if (!is_user_logged_in () && username_exists ($s["username"]) && (!is_multisite () || !c_ws_plugin__s2member_utils_users::ms_user_login_email_can_join_blog ($s["username"], $s["email"])))
											$response = array ("response" => 'That Username is already in use. Please try again.', "error" => true);
										/**/
										else if (!is_user_logged_in () && is_multisite () && !c_ws_plugin__s2member_utils_users::ms_user_login_email_can_join_blog ($s["username"], $s["email"]) && ($_response = wpmu_validate_user_signup ($s["username"], $s["email"])) && is_wp_error ($_errors = $_response["errors"]) && $_errors->get_error_message ())
											$response = array ("response" => $_errors->get_error_message (), "error" => true);
										/**/
										else if (!is_user_logged_in () && (!$s["password1"] || !is_string ($s["password1"])) && $GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["custom_reg_password"])
											$response = array ("response" => 'Missing Password. Please try again.', "error" => true);
										/**/
										else if (!is_user_logged_in () && strlen ($s["password1"]) < 6 && $GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["custom_reg_password"])
											$response = array ("response" => 'Invalid Password. Must be at least 6 characters. Please try again.', "error" => true);
										/**/
										else if (!is_user_logged_in () && strlen ($s["password1"]) > 20 && $GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["custom_reg_password"])
											$response = array ("response" => 'Invalid Password. Max length is 20 characters. Please try again.', "error" => true);
										/**/
										else if (!is_user_logged_in () && $s["password2"] !== $s["password1"] && $GLOBALS["WS_PLUGIN__"]["s2member"]["o"]["custom_reg_password"])
											$response = array ("response" => 'Password fields do NOT match. Please try again.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if (!$s["card_type"] || !is_string ($s["card_type"]))
											$response = array ("response" => 'Missing Card Type ( Billing Method ). Please try again.', "error" => true);
										/**/
										else if (!in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo", "PayPal")))
											$response = array ("response" => 'Invalid Card Type ( Billing Method ). Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["card_number"] || !is_string ($s["card_number"])))
											$response = array ("response" => 'Missing Card Number. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["card_expiration"] || !is_string ($s["card_expiration"])))
											$response = array ("response" => 'Missing Card Expiration Date ( mm/yyyy ). Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && !preg_match ("/^[0-9]{2}\/[0-9]{4}$/", $s["card_expiration"]))
											$response = array ("response" => 'Invalid Card Expiration Date. Must be in this format ( mm/yyyy ). Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["card_verification"] || !is_string ($s["card_verification"])))
											$response = array ("response" => 'Missing Card Verification Code. It\'s on the back of your Card. 3-4 digits. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Maestro", "Solo")) && (!$s["card_start_date_issue_number"] || !is_string ($s["card_start_date_issue_number"])))
											$response = array ("response" => 'Missing Card Start Date, or Issue #. Required for Maestro/Solo. Please try again.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["street"] || !is_string ($s["street"])))
											$response = array ("response" => 'Missing Street Address. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["city"] || !is_string ($s["city"])))
											$response = array ("response" => 'Missing City/Town. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["state"] || !is_string ($s["state"])))
											$response = array ("response" => 'Missing State/Province. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["country"] || !is_string ($s["country"])))
											$response = array ("response" => 'Missing Country. Please try again.', "error" => true);
										/**/
										else if (in_array ($s["card_type"], array ("Visa", "MasterCard", "Discover", "Amex", "Maestro", "Solo")) && (!$s["zip"] || !is_string ($s["zip"])))
											$response = array ("response" => 'Missing Postal/Zip Code. Please try again.', "error" => true);
										/* ----------------------------------------------------------------------------------------------------------------- */
										else if ($s["attr"]["captcha"] && (!$s["recaptcha_challenge_field"] || !$s["recaptcha_response_field"] || !c_ws_plugin__s2member_utils_captchas::recaptcha_code_validates ($s["recaptcha_challenge_field"], $s["recaptcha_response_field"])))
											$response = array ("response" => 'Missing or invalid Security Code. Please try again.', "error" => true); /* Missing or invalid Captcha/Security Code. */
									}
								else /* Else we are dealing with an unknown form submission type. */
									$response = array ("response" => 'Unknown form submission type. Please contact Support.', "error" => true);
							}
						/**/
						return (empty ($response)) ? null : $response;
					}
			}
	}
?>