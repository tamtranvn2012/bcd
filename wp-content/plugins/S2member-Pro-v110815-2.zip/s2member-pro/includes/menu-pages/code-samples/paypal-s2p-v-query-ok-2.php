<?php
if (s2member_pro_paypal_s2p_v_query_ok ($_SERVER["QUERY_STRING"], "ignore-time"))
	{
		echo 'Looks good. Verified; regardless of time.';
	}
?>