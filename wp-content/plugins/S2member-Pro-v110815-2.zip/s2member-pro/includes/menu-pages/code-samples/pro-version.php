<?php echo S2MEMBER_PRO_VERSION; ?>
This may output something like: 110606
( or whatever the current version number is )
Use PHP's version_compare() function to test this.

Note: s2Member Pro versions now follow their release date.
Ex: s2Member Pro v110606 was released June 6th 2011.
 ( YYMMDD format )

---- s2member Shortcode Equivalent ----

[s2Get constant="S2MEMBER_PRO_VERSION" /]